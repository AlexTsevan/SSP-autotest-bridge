import argparse
from .bridge import devices, bridge_check, run_operation


def main():
    parser = argparse.ArgumentParser(description="SSP test bridge CLI")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("devices")
    sub.add_parser("bridge-check")
    op = sub.add_parser("run")
    op.add_argument("operation", choices=["payment", "cancel", "refund", "reconciliation"])
    op.add_argument("--amount")
    op.add_argument("--rrn")
    args = parser.parse_args()

    if args.command == "devices":
        print(devices())
    elif args.command == "bridge-check":
        print(bridge_check())
    else:
        print(run_operation(args.operation, args.amount, args.rrn))


if __name__ == "__main__":
    main()
