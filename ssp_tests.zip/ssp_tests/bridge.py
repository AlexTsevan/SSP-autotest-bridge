﻿from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


class BridgeError(RuntimeError):
    pass


def _adb(*args: str, timeout: int = 15) -> str:
    cmd = [CONFIG["adb_path"]]
    serial = CONFIG.get("device_serial", "").strip()
    if serial:
        cmd += ["-s", serial]
    cmd += list(args)
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False)
    except FileNotFoundError as exc:
        raise BridgeError("adb РЅРµ РЅР°Р№РґРµРЅ. РЈСЃС‚Р°РЅРѕРІРёС‚Рµ Android Platform Tools Рё РґРѕР±Р°РІСЊС‚Рµ adb РІ PATH.") from exc
    except subprocess.TimeoutExpired as exc:
        raise BridgeError(f"ADB timeout: {' '.join(cmd)}") from exc
    if p.returncode:
        raise BridgeError(f"РљРѕРјР°РЅРґР° Р·Р°РІРµСЂС€РёР»Р°СЃСЊ СЃ РєРѕРґРѕРј {p.returncode}: {' '.join(cmd)}\n{p.stderr.strip()}")
    return (p.stdout or "").strip()


def devices() -> str:
    return _adb("devices", "-l")


def require_one_device() -> None:
    output = devices()
    rows = [line for line in output.splitlines()[1:] if line.strip()]
    usable = [row for row in rows if " device" in row and "unauthorized" not in row]
    if not usable:
        raise BridgeError(f"ADB-СѓСЃС‚СЂРѕР№СЃС‚РІРѕ РЅРµ РіРѕС‚РѕРІРѕ. Р’С‹РІРѕРґ adb devices -l:\n{output}")
    serial = CONFIG.get("device_serial", "").strip()
    if not serial and len(usable) != 1:
        raise BridgeError(
            f"РќР°Р№РґРµРЅРѕ СѓСЃС‚СЂРѕР№СЃС‚РІ СЃРѕ СЃС‚Р°С‚СѓСЃРѕРј device: {len(usable)}. "
            "РЈРєР°Р¶РёС‚Рµ serial РІ config.json, С‡С‚РѕР±С‹ РёСЃРєР»СЋС‡РёС‚СЊ Р·Р°РїСѓСЃРє РЅР° РЅРµРІРµСЂРЅРѕРј С‚РµСЂРјРёРЅР°Р»Рµ.\n" + output
        )


def bridge_check() -> str:
    require_one_device()
    component = CONFIG["bridge_component"]
    # РљРѕРјР°РЅРґР° status РґРѕР»Р¶РЅР° Р±С‹С‚СЊ СЂРµР°Р»РёР·РѕРІР°РЅР° Android bridge Рё РЅРµ РґРѕР»Р¶РЅР° Р·Р°РїСѓСЃРєР°С‚СЊ РїР»Р°С‚С‘Р¶.
    return _adb("shell", "am", "start", "-W", "-n", component, "--es", "operation", "status", timeout=20)


def run_operation(operation: str, amount: str | None = None, rrn: str | None = None) -> dict[str, Any]:
    if operation not in {"payment", "cancel", "refund", "reconciliation", "status"}:
        raise ValueError(f"Unsupported operation: {operation}")
    require_one_device()
    if operation in {"payment", "cancel", "refund"} and not amount:
        raise ValueError("Р”Р»СЏ С„РёРЅР°РЅСЃРѕРІРѕР№ РѕРїРµСЂР°С†РёРё РЅСѓР¶РЅРѕ СѓРєР°Р·Р°С‚СЊ amount.")
    if operation in {"cancel", "refund"} and not rrn:
        raise ValueError("Р”Р»СЏ cancel/refund РЅСѓР¶РЅРѕ СѓРєР°Р·Р°С‚СЊ RRN РёСЃС…РѕРґРЅРѕР№ РѕРїРµСЂР°С†РёРё.")

    # РЈРґР°Р»СЏРµРј СЃС‚Р°СЂС‹Рµ СЂРµР·СѓР»СЊС‚Р°С‚С‹, С‡С‚РѕР±С‹ РЅРµ РїСЂРёРЅСЏС‚СЊ РїСЂРѕС€Р»С‹Р№ СЂРµР·СѓР»СЊС‚Р°С‚ Р·Р° С‚РµРєСѓС‰РёР№.
    _adb("logcat", "-c")
    args = ["shell", "am", "start", "-W", "-n", CONFIG["bridge_component"],
            "--es", "operation", operation]
    if amount:
        args += ["--es", "amount", amount]
    if rrn:
        args += ["--es", "rrn", rrn]
    start_output = _adb(*args, timeout=25)

    deadline = time.monotonic() + int(CONFIG.get("timeout_seconds", 240))
    prefix = CONFIG.get("logcat_tag_prefix", "SSP_BRIDGE_RESULT:")
    while time.monotonic() < deadline:
        log = _adb("logcat", "-d", "-v", "brief", timeout=20)
        candidates = [line.split(prefix, 1)[1].strip()
                      for line in log.splitlines() if prefix in line]
        if candidates:
            try:
                result = json.loads(candidates[-1])
            except json.JSONDecodeError as exc:
                raise BridgeError(f"Bridge РІРµСЂРЅСѓР» РЅРµРєРѕСЂСЂРµРєС‚РЅС‹Р№ JSON: {candidates[-1]}") from exc
            result.setdefault("operation", operation)
            return result
        time.sleep(1)

    raise BridgeError(
        f"РСЃС‚РµРєР»Рѕ РѕР¶РёРґР°РЅРёРµ СЂРµР·СѓР»СЊС‚Р°С‚Р° SSP ({CONFIG.get('timeout_seconds')} СЃРµРє.). "
        "РќРµ РїРѕРІС‚РѕСЂСЏР№С‚Рµ РѕРїРµСЂР°С†РёСЋ РІСЃР»РµРїСѓСЋ: РїСЂРѕРІРµСЂСЊС‚Рµ СЌРєСЂР°РЅ С‚РµСЂРјРёРЅР°Р»Р° Рё Р¶СѓСЂРЅР°Р» SSP. "
        f"Р’С‹РІРѕРґ Р·Р°РїСѓСЃРєР° Activity:\n{start_output}"
    )

def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="SSP Android bridge CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("devices")
    sub.add_parser("bridge-check")

    run = sub.add_parser("run")
    run.add_argument("operation", choices=["payment", "cancel", "refund", "reconciliation", "status"])
    run.add_argument("--amount")
    run.add_argument("--rrn")

    args = parser.parse_args()
    try:
        if args.command == "devices":
            print(devices())
        elif args.command == "bridge-check":
            print(bridge_check())
        elif args.command == "run":
            print(json.dumps(
                run_operation(args.operation, args.amount, args.rrn),
                ensure_ascii=False,
                indent=2
            ))
    except (BridgeError, ValueError, KeyError) as exc:
        raise SystemExit(f"РћС€РёР±РєР°: {exc}")


if __name__ == "__main__":
    main()

