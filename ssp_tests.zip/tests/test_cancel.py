import pytest
from ssp_tests.bridge import run_operation


@pytest.mark.cancel
@pytest.mark.manual_card
def test_cancel_by_rrn(amount, rrn):
    result = run_operation("cancel", amount=amount, rrn=rrn)
    assert result.get("operation") in {"cancel", "refund"}, result
    assert result.get("activityResult") == "OK", result
    assert result.get("code") == 0, result
    assert result.get("isApproved") is True, result
