import os
import pytest


@pytest.fixture
def amount():
    return os.getenv("SSP_AMOUNT", "100.00")


@pytest.fixture
def rrn():
    value = os.getenv("SSP_RRN", "").strip()
    if not value:
        pytest.skip("Задайте SSP_RRN для отмены/возврата успешно проведённой тестовой оплаты.")
    return value
