import pytest
from ssp_tests.bridge import run_operation


@pytest.mark.payment
@pytest.mark.manual_card
def test_payment_approved(amount):
    result = run_operation("payment", amount=amount)
    assert result.get("operation") == "payment", result
    assert result.get("activityResult") == "OK", result
    assert result.get("code") == 0, result
    assert result.get("isApproved") is True, result
    assert result.get("rrn"), f"Нет RRN в результате, отмену/возврат пока запускать нельзя: {result}"
