import pytest
from ssp_tests.bridge import run_operation


@pytest.mark.reconciliation
def test_reconciliation_result():
    result = run_operation("reconciliation")
    assert result.get("operation") == "reconciliation", result
    assert result.get("activityResult") == "OK", result
    assert result.get("code") == 0, result
    # SSP docs warn: reconciliation can close shift even when host RC is unsuccessful.
    # Therefore code==0 alone is not enough for business acceptance; review rc/message/log.
    assert result.get("rc") == "00", f"Смена могла закрыться с неуспешным RC; проверьте лог: {result}"
