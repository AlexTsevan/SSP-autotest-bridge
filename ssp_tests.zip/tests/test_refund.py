import pytest
from ssp_tests.bridge import run_operation


@pytest.mark.refund
@pytest.mark.manual_card
def test_refund_by_rrn(amount, rrn):
    result = run_operation("refund", amount=amount, rrn=rrn)
    assert result.get("operation") in {"refund", "cancel"}, result
    assert result.get("activityResult") == "OK", result
    assert result.get("code") == 0, result
    assert result.get("isApproved") is True, result
