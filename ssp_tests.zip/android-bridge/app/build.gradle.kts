plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.example.ssptestbridge"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.example.ssptestbridge"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlinOptions {
    jvmTarget = "17"
}
    }
}

dependencies {
    // TODO: add SSP AAR supplied for API 1.9.18 SR2.
    // Example if placed in app/libs/ssp-api.aar:
    // implementation(files("libs/ssp-api.aar"))
}
