package ru.example.ssptestbridge

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import org.json.JSONObject
import java.math.BigDecimal

/*
 * TEMPLATE ONLY: attach the SSP AAR and adjust package/imports/constants to that AAR.
 * API 1.9.18 SR2 documentation shows:
 *   Intent action: com.skytech.smartskypos.PAYMENT
 *   SSP package: com.skytech.smartskypos
 *   params key: PaymentActivity.PARAMS_KEY
 *   type key: PaymentActivity.TYPE_KEY
 *   TransactionParams(BigDecimal(amount))
 *
 * Verify exact constants and Parcelable class names against the supplied AAR before building.
 */
class MainActivity : Activity() {
    companion object {
        private const val TAG = "SSPTestBridge"
        private const val SSP_ACTION = "com.skytech.smartskypos.PAYMENT"
        private const val SSP_PACKAGE = "com.skytech.smartskypos"
        private const val REQUEST_SSP = 7101
        private const val RESULT_PREFIX = "SSP_BRIDGE_RESULT:"
    }

    private var operation: String = "status"
    private var requestedAmount: String? = null
    private var requestedRrn: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        operation = intent.getStringExtra("operation") ?: "status"
        requestedAmount = intent.getStringExtra("amount")
        requestedRrn = intent.getStringExtra("rrn")

        if (operation == "status") {
            emit(JSONObject()
                .put("operation", "status")
                .put("activityResult", "OK")
                .put("code", 0)
                .put("message", "Bridge Activity started; SSP operation not invoked"))
            finish()
            return
        }

        try {
            launchSspOperation()
        } catch (t: Throwable) {
            emit(JSONObject()
                .put("operation", operation)
                .put("activityResult", "ERROR")
                .put("code", -1)
                .put("message", t.message ?: t.javaClass.simpleName))
            finish()
        }
    }

    private fun launchSspOperation() {
        /*
         * TODO (requires SSP AAR):
         *
         * import com.skytech.smartskyposlib.TransactionParams
         * import com.skytech.smartskyposlib.PaymentActivity
         *
         * val params = TransactionParams(BigDecimal(requestedAmount ?: "0.00"))
         * if (operation == "cancel" || operation == "refund") {
         *     // Set params.rrn using the actual API field/setter in the supplied AAR.
         * }
         * val type = when (operation) {
         *   "payment" -> PaymentActivity.TYPE_PAYMENT
         *   "cancel" -> PaymentActivity.TYPE_CANCEL
         *   "refund" -> PaymentActivity.TYPE_REFUND
         *   "reconciliation" -> PaymentActivity.TYPE_RECONCILIATION
         *   else -> error("Unsupported operation")
         * }
         * val sspIntent = Intent(SSP_ACTION).setPackage(SSP_PACKAGE)
         * sspIntent.putExtra(PaymentActivity.PARAMS_KEY, params)
         * sspIntent.putExtra(PaymentActivity.TYPE_KEY, type)
         * startActivityForResult(sspIntent, REQUEST_SSP)
         *
         * NOTE: documentation describes AIDL reconciliation() with no params.
         * Confirm the Intent reconciliation flow in the actual AAR/installed SSP.
         * If unsupported, implement via AIDL: bind action com.skytech.smartskypos.ISmartSkyPos,
         * wait for READY, call reconciliation(), then emit its ReconciliationResult.
         */
        error("SSP AAR integration is not completed. See TODO in MainActivity.kt")
    }

    @Deprecated("Use Activity Result API in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SSP) return

        // TODO: extract TransactionResult / ReconciliationResult fields using exact Parcelable
        // APIs in the supplied AAR, then emit normalized JSON expected by Python.
        val json = JSONObject()
            .put("operation", operation)
            .put("activityResult", if (resultCode == Activity.RESULT_OK) "OK" else "CANCELED")
            .put("code", -2)
            .put("message", "TODO: parse SSP result Parcelable from AAR")
        emit(json)
        finish()
    }

    private fun emit(json: JSONObject) {
        Log.i(TAG, RESULT_PREFIX + json.toString())
    }
}
