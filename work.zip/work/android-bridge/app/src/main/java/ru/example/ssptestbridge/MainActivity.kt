package ru.example.ssptestbridge

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.skytech.smartskyposlib.Constants
import com.skytech.smartskyposlib.TransactionParams
import com.skytech.smartskyposlib.TransactionResult
import com.skytech.smartskyposlib.ReconciliationResult
import org.json.JSONObject
import java.math.BigDecimal

class MainActivity : Activity() {

    companion object {
        private const val TAG = "SSPTestBridge"
        private const val ACTION = "com.skytech.smartskypos.PAYMENT"
        private const val SSP_PACKAGE = "com.skytech.smartskypos"
        private const val REQUEST_SSP = 7101
        private const val PREFIX = "SSP_BRIDGE_RESULT:"
    }

    private var operation = "status"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        operation = intent.getStringExtra("operation") ?: "status"
        Log.i(TAG, "BRIDGE_START: operation=$operation")

        if (operation == "status") {
            emit(
                JSONObject()
                    .put("operation", "status")
                    .put("activityResult", "OK")
                    .put("code", 0)
                    .put("message", "Bridge started")
            )
            finish()
            return
        }

        try {
            val type = when (operation) {
                "payment" -> Constants.TYPE_PAYMENT
                "cancel" -> Constants.TYPE_CANCEL
                "refund" -> Constants.TYPE_REFUND
                "reconciliation" -> Constants.TYPE_RECONCILIATION
                else -> error("Unsupported operation: $operation")
            }

            val params = when (operation) {
                "reconciliation" -> TransactionParams()

                else -> {
                    val amount = intent.getStringExtra("amount")
                        ?: error("Missing amount")

                    require(BigDecimal(amount) > BigDecimal.ZERO) {
                        "Amount must be greater than zero"
                    }

                    TransactionParams(BigDecimal(amount)).apply {
                        if (operation == "cancel" || operation == "refund") {
                            rrn = intent.getStringExtra("rrn")
                                ?.takeIf { it.isNotBlank() }
                                ?: error("Missing rrn")
                        }
                    }
                }
            }

            val sspIntent = Intent(ACTION).apply {
                setPackage(SSP_PACKAGE)
                putExtra(Constants.TYPE_KEY, type)
                putExtra(Constants.PARAMS_KEY, params)
            }

            Log.i(TAG, "SSP_START: operation=$operation type=$type")
            startActivityForResult(sspIntent, REQUEST_SSP)
            Log.i(TAG, "SSP_START: startActivityForResult called")

        } catch (t: Throwable) {
            Log.e(TAG, "SSP_START_ERROR", t)

            emit(
                JSONObject()
                    .put("operation", operation)
                    .put("activityResult", "ERROR")
                    .put("code", -1)
                    .put("message", t.message ?: t.javaClass.simpleName)
            )

            finish()
        }
    }

    @Deprecated("Compatibility with the SSP Activity result API")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != REQUEST_SSP) return

        Log.i(
            TAG,
            "SSP_RETURN: requestCode=$requestCode " +
                "resultCode=$resultCode dataNull=${data == null}"
        )

        try {
            if (resultCode != RESULT_OK || data == null) {
                emit(
                    JSONObject()
                        .put("operation", operation)
                        .put("activityResult", "CANCELED")
                        .put("code", -2)
                        .put("message", "SSP returned no successful result")
                )
                return
            }

            if (operation == "reconciliation") {
                val result = data.getParcelableExtra<ReconciliationResult>(
                    Constants.RECONCILIATION_RESULT_KEY
                ) ?: error("Missing reconciliationResult")

                Log.i(TAG, "SSP_RESULT: reconciliation code=${result.code}")

                emit(
                    JSONObject()
                        .put("operation", operation)
                        .put("activityResult", "OK")
                        .put("code", result.code)
                        .put("message", result.message ?: "")
                        .put("rc", result.rc ?: "")
                        .put("rrn", result.rrn ?: "")
                        .put("approved", result.isApproved() ?: false)
                        .put("slip", result.slip ?: "")
                )

            } else {
                val result = data.getParcelableExtra<TransactionResult>(
                    Constants.TRANSACTION_RESULT_KEY
                ) ?: error("Missing transactionResult")

                Log.i(
                    TAG,
                    "SSP_RESULT: operation=$operation code=${result.code} " +
                        "approved=${result.isApproved()}"
                )

                emit(
                    JSONObject()
                        .put("operation", operation)
                        .put("activityResult", "OK")
                        .put("code", result.code)
                        .put("message", result.message ?: "")
                        .put("rc", result.rc ?: "")
                        .put("rrn", result.rrn ?: "")
                        .put("authCode", result.authCode ?: "")
                        .put("approved", result.isApproved() ?: false)
                        .put("amount", result.amount?.toPlainString() ?: "")
                        .put("slip", result.slip ?: "")
                )
            }

        } catch (t: Throwable) {
            Log.e(TAG, "SSP_RESULT_ERROR", t)

            emit(
                JSONObject()
                    .put("operation", operation)
                    .put("activityResult", "ERROR")
                    .put("code", -3)
                    .put("message", t.message ?: t.javaClass.simpleName)
            )

        } finally {
            finish()
        }
    }

    private fun emit(json: JSONObject) {
        Log.i(TAG, PREFIX + json.toString())
    }
}